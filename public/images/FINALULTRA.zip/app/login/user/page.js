import LoginUser from '@/app/components/LoginUser';

export default function UserLoginPage() {
  return <LoginUser />;
}