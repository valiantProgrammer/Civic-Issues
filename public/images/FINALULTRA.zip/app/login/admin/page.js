import LoginAdmin from '@/app/components/LoginAdmin';

export default function AdminLoginPage() {
  return <LoginAdmin />;
}