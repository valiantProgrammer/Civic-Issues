import LoginAdministration from '@/app/components/LoginAdministrative';

export default function AdministrativeLoginPage() {
  return <LoginAdministration />;
}