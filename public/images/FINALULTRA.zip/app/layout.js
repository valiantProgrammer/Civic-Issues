import { Nunito } from 'next/font/google';
import Script from 'next/script';
import './globals.css';

// Configure the font with desired weights
const nunito = Nunito({
  subsets: ['latin'],
  weight: ['400', '700', '800'],
  variable: '--font-nunito', // Use a CSS variable
});

export const metadata = {
  title: 'Civic Saathi',
  description: 'The best place to learn and play for kids',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      {/* Apply the font variable to the body */}
      <body className={`${nunito.variable} font-sans`}>{children}

        <Script
          src={`https://apis.mappls.com/advancedmaps/api/${process.env.NEXT_PUBLIC_MAPMYINDIA_MAP_KEY}/map_sdk?v=3.0&layer=vector`}
          strategy="beforeInteractive"
        />
      </body>
    </html>
  );
}
// In app/layout.js

// import { Nunito } from 'next/font/google';
// import Script from 'next/script';
// import { Toaster } from 'react-hot-toast';
// import './globals.css';

// const nunito = Nunito({
//   subsets: ['latin'],
//   weight: ['400', '700', '800'],
//   variable: '--font-nunito',
// });

// export const metadata = {
//   title: 'WonderKids',
//   description: 'The best place to learn and play for kids',
// };

// export default function RootLayout({ children }) {
//   return (
//     <html lang="en">
//       <head>
//         {/*
//           CRITICAL: Pannellum CSS must be loaded before rendering.
//           Using a standard <link> tag here.
//         */}
//         <link
//           rel="stylesheet"
//           href="https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.css"
//           // Adding referrerpolicy and crossorigin for robustness, though usually not strictly needed for CDNs.
//           referrerPolicy="no-referrer"
//           crossOrigin="anonymous"
//         />
//       </head>
//       <body className={`${nunito.variable} font-sans bg-gray-50 text-gray-900`}>
//         <Toaster position="top-center" reverseOrder={false} />
//         <main>{children}</main>

//         {/*
//           CRITICAL: Pannellum JS must load before any React component tries to access window.pannellum.
//           Strategy "beforeInteractive" is usually sufficient, but we're explicitly ensuring order.
//         */}
//         <Script
//           src="https://cdn.jsdelivr.net/npm/pannellum@2.5.6/build/pannellum.js"
//           strategy="beforeInteractive" // Load before React hydration
//           // Adding referrerpolicy and crossorigin for robustness
//           referrerPolicy="no-referrer"
//           crossOrigin="anonymous"
//           // Add an onLoad handler to confirm it loaded
//           onLoad={() => console.log('Pannellum JS loaded via Next.js Script!')}
//           onError={(e) => console.error('Pannellum JS failed to load:', e)}
//         />

//         {/* Mappls SDK Script */}
//         <Script
//           src={`https://apis.mappls.com/advancedmaps/api/${process.env.NEXT_PUBLIC_MAPMYINDIA_MAP_KEY}/map_sdk?v=3.0&layer=vector`}
//           strategy="beforeInteractive"
//           onLoad={() => console.log('Mappls JS loaded via Next.js Script!')}
//           onError={(e) => console.error('Mappls JS failed to load:', e)}
//         />
//       </body>
//     </html>
//   );
// }