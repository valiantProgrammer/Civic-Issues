export default function Footer() {
  return (
    <footer className="text-black text-center py-[3vh] md:py-[5vh]">
      <p className="text-[3vw] md:text-[1vw]">&copy; 2025 Our Site. All rights reserved.</p>
    </footer>
  );
}