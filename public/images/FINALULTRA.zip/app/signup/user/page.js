import SignupUser from '@/app/components/SignupUser';

export default function UserSignupPage() {
  return <SignupUser />;
}