import { NextResponse } from 'next/server';
import { verifyToken } from './lib/auth'; // Using relative path for middleware

export default async function middleware(request) {
    const { pathname } = request.nextUrl;
    const accessToken = request.cookies.get('accessToken')?.value;

    // A generic login URL. You can customize this if you have separate login pages.
    const loginUrl = new URL('/login', request.url);

    // 1. If there's no token, redirect to the login page immediately.
    if (!accessToken) {
        return NextResponse.redirect(loginUrl);
    }

    try {
        // 2. Verify the token to get the user's role and ID.
        const payload = await verifyToken(accessToken);

        // If the token is invalid or expired, the payload will be null.
        if (!payload) {
            // It's good practice to clear a potentially invalid cookie.
            const response = NextResponse.redirect(loginUrl);
            response.cookies.delete('accessToken');
            response.cookies.delete('refreshToken');
            return response;
        }

        const { role } = payload;
        console.log(role)

        // 3. Check authorization based on the user's role and the requested path.

        // // Rule: Only 'user' role can access /user/* pages.
        if (pathname.startsWith('/user') && role !== 'user') {
            return NextResponse.redirect(new URL('/unauthorized', request.url)); // Or a generic home page
        }

        // Rule: Only 'admin' role can access /admin/* pages.
        if (pathname.startsWith('/admin') && role !== 'admin') {
            return NextResponse.redirect(new URL('/unauthorized', request.url));
        }
        // Rule: Only 'adminHead' can access /administration/* pages.
        else if (pathname.startsWith('/administration') && role !== 'adminHead') {
            return NextResponse.redirect(new URL('/unauthorized', request.url));
        }

        // Rule: Only 'admin' or 'adminHead' can access the signup pages for new admins.
        // else if ((pathname.startsWith('/admin-signup') || pathname.startsWith('/administration-signup')) && (role !== 'admin' && role !== 'adminHead')) {
        //     return NextResponse.redirect(new URL('/unauthorized', request.url));
        // }

        // 4. If all checks pass, allow the request to continue.
        return NextResponse.next();

    } catch (error) {
        console.error('Middleware error:', error);
        // In case of any unexpected error during token verification, redirect to login.
        return NextResponse.redirect(loginUrl);
    }
}

// The 'matcher' configuration specifies which paths this middleware will run on.
export const config = {
    matcher: [
        '/user/:path*',
        '/admin/:path*',
        // '/administration/:path*',
        // '/admin-signup/:path*',
        // '/administration-signup/:path*',
    ],
};
